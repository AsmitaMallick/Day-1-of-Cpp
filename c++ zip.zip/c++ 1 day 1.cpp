#include<iostream>
using namespace std;
int main()
{
	int a=3;
	int b=6;
	cout<<"this is the codes of c language.The value of a is "<< a <<"The value of b is "<<b;
	 return 0;
}
