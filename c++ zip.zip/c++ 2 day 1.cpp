#include<iostream>
using namespace std;
int main()
{ int i=8;
float f=3.1;
double d=5.55;
char c='s';
bool b=true;
cout <<" The value of i is "<<i<<"\nThe value of f is "<<f<<"\nThe value of double is "<<d<<"\nThe value of boolean is "<<b<<"\nThe value of char is "<<c;
	
	 return 0;
}
