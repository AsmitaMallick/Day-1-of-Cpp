#include<iostream>
using namespace std;
int main()
{
	int a;
	int b;
	
	cout<<"enter the value of a is ";
	cin>>a;
	cout<<"enter the value of b is ";
	cin>>b;
	cout<<"The sum of a and b is "<<a+b;
	
	
	 return 0;
}
